﻿using System;

namespace ADAGreetings
{
    public class Class1
    {
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADAGreetings
{
    public class CustomMessages
    {
        public static readonly string Hi = "Hi ";
        public static readonly string ThanksJoining = " thanks for joining the stand-up";
        public static readonly string NotSureJoined = "I'm not sure who has joined, anyway thanks for joining...";
        public static readonly List<string> HiHey = new List<string> { "Hi ", "Hello ", "Dude ", "Hey " };
        public static readonly List<string> JoinMessage = new List<string> { ThanksJoining, " thanks for joining", " thank you for joining", " much appreciated for joining", " appreciated for joining the standup" };
        
    }
}

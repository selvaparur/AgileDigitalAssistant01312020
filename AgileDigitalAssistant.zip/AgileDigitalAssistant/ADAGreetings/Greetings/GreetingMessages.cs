﻿using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Microsoft.Bot.Builder.Dialogs;
using System.Threading;
using System.Threading.Tasks;
using ADAFramework;
using ADADomain;

namespace ADAGreetings
{
    public class GreetingMessages : ComponentDialog
    {
        int starttm = 0;
        int endtm = 0;
        public GreetingMessages()
        {

            starttm = DateTime.Now.Minute;
            endtm = starttm + 1;            

            AddDialog(new TextPrompt(nameof(TextPrompt)));

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]{
                WelcomeAsync,
                ThanksAsync
            }));

            InitialDialogId = nameof(WaterfallDialog);
        }

        public async Task<DialogTurnResult> WelcomeAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            if (context.Options != null)
            {
                //if (starttm >= endtm)
                if (context.Options.ToString().ToLower().Contains("jackson") || context.Options.ToString().ToLower().Contains("jacob"))
                {
                    return await context.EndDialogAsync(null, cancellationToken);
                }

                var random = new Random();

                string greetingsDomain = (string)context.Options;

                var wel = MessageFactory.Text("");
                if (!string.IsNullOrEmpty(greetingsDomain))
                {
                    var mess = "";

                    string strName = IntentParser.GetIntents(greetingsDomain);
                    Intents intents = IntentProccessor.IntentDetails(strName);

                    if (!string.IsNullOrEmpty(intents.topScoringIntent.intent))
                    {
                        string strIntent = intents.topScoringIntent.intent;
                        switch (strIntent)
                        {
                            case "UserJoiningMessageIntent":
                                if (intents.entities.Length > 0)
                                {
                                    greetingsDomain = ADAFramework.Common.GetFirstLetterUpper(intents.entities[0].entity);
                                }
                                else
                                {
                                    greetingsDomain = " dude ";
                                }
                                mess = CustomMessages.HiHey[random.Next(CustomMessages.HiHey.Count)] + greetingsDomain + CustomMessages.JoinMessage[random.Next(CustomMessages.JoinMessage.Count)]; // CustomMessages.Hi+ greetingsDomain + CustomMessages.ThanksJoining;
                                break;

                            default:
                                greetingsDomain = " dude ";
                                break;
                        }
                    }

                    //greetingsDomain = greetingsDomain.ToLower().Replace("joined", "").Replace("has joined", "").Replace("here", "").Replace("hi", "").Replace("hello", "").Replace("hey", "");
                                        
                    wel = MessageFoctoryWrapper.GetFormattedMessage(mess);

                }
                return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = wel }, cancellationToken);
            }
            else
            {
                var notsure = MessageFoctoryWrapper.GetFormattedMessage(CustomMessages.NotSureJoined);
                return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = notsure }, cancellationToken);
            }

        }

        public async Task<DialogTurnResult> ThanksAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            starttm = DateTime.Now.Minute;

            return await context.ReplaceDialogAsync(nameof(GreetingMessages), context.Result, cancellationToken);
            //return await context.EndDialogAsync(null,cancellationToken);
        }
    }
}

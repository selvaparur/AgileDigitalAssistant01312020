﻿using System;

namespace ImpedimentsHandler
{
    public class Class1
    {
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADADomain
{
  public  class Intents
    {
        public string query { get; set; }
        public TopScoringIntent topScoringIntent { get; set; }
        public Entities[] entities { get; set; }
    }

    public class TopScoringIntent
    {
        public string intent { get; set; }
        public decimal score { get; set; }
    }

    public class Entities
    {
        public string entity { get; set; }
        public string type { get; set; }
        public string startIndex { get; set; }
        public string endIndex { get; set; }
        public decimal score { get; set; }
    }
}

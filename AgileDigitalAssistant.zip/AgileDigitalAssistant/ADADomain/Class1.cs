﻿using System;

namespace ADADomain
{
    public class Class1
    {
    }
}

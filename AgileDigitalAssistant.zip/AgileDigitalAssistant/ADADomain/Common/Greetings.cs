﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADADomain
{
  public  class GreetingsDomain
    {
        public string UserID { get; set; }
        public string UserName { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Microsoft.Bot.Builder.Dialogs;
using System.Threading.Tasks;
using System.Threading;
using ADAQuestionBank;
using ADAFramework;


namespace WindupHandler
{
    public class Windup : ComponentDialog
    {
        public Windup()
        {
            AddDialog(new TextPrompt(nameof(TextPrompt)));

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog),new WaterfallStep[] {

                WindupStartAsync,
                ThanksPOAsync,
                TeamAskAsync,
                FinalAsync
            }));

            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> WindupStartAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            var message = MessageFoctoryWrapper.GetFormattedMessage(WindupQuestions.WindUp);

            await context.Context.SendActivityAsync(message, cancellationToken);

            var POask = MessageFoctoryWrapper.GetFormattedMessage(WindupQuestions.ProductOwnerTrun);

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = POask }, cancellationToken);
        }

        private async Task<DialogTurnResult> ThanksPOAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            var message = MessageFoctoryWrapper.GetFormattedMessage(WindupQuestions.ThanksPO);            

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = message }, cancellationToken);
        }

        private async Task<DialogTurnResult> TeamAskAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            var message = MessageFoctoryWrapper.GetFormattedMessage(WindupQuestions.TeamAsk);

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = message }, cancellationToken);
        }

        private async Task<DialogTurnResult> BotFinalUpdateAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            var message = MessageFoctoryWrapper.GetFormattedMessage(WindupQuestions.TeamAsk);

            await context.Context.SendActivityAsync(message, cancellationToken);

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = message }, cancellationToken);
        }

        private async Task<DialogTurnResult> FinalAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            
            return await context.EndDialogAsync(null, cancellationToken);
        }
    }
}

﻿using System;

namespace CommonHandler
{
   public class Class1
    {
    }
}

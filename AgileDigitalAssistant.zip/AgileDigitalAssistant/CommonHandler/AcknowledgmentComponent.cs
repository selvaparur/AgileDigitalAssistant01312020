﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Microsoft.Bot.Builder.Dialogs;
using System.Threading.Tasks;
using System.Threading;
using ADAFramework;
using ADAQuestionBank;

namespace CommonHandler
{
    public class AcknowledgmentComponent : ComponentDialog
    {
        string strUsers = string.Empty;

        public AcknowledgmentComponent()
        {
            AddDialog(new TextPrompt(nameof(TextPrompt)));

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[] {

                StartAsync,                
                StopAsync
            }));

            InitialDialogId = nameof(WaterfallDialog);
        }

        public async Task<DialogTurnResult> StartAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            string strUser = string.Empty;

            if (context.Options != null)
            {
                strUsers = strUser;
                strUser = (string)context.Options;

            }

            var storyshapt = MessageFoctoryWrapper.GetFormattedMessage(CommonMessages.StoryGoodShape + CommonMessages.MoveNextStory);
            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = storyshapt }, cancellationToken);
        }       

        public async Task<DialogTurnResult> StopAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            return await context.EndDialogAsync(null, cancellationToken);
        }
    }
}

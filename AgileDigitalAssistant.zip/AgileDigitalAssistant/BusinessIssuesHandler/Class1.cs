﻿using System;

namespace BusinessIssuesHandler
{
    public class Class1
    {
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADAQuestionBank
{
    public class DependencyQuestions
    {
        public static readonly string DependencyDetails = "What type of dependency it is, Can you please explain in details….";
        public static readonly string DepBotAttention = "Cool.. thanks for the detail.. Please schedule a call or work with the dependency team/person and make it closure…";
    }
}

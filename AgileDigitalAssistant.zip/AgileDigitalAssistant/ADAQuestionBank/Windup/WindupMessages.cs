﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADAQuestionBank
{
    public class WindupQuestions
    {
        public static readonly string WindUp = "Ok, we have done with the stories & it’s time for winding up the standup. Over to Product Owner, would you like to address the team on updates";

        public static readonly string ProductOwnerTrun = "Over to Product Owner, would you like to address the team on updates";

        public static readonly string TeamAsk = "Ok team, anything else to discuss…";

        public static readonly string ThanksPO = "Thanks for sharing the udpate ProductOwner.";

        public static readonly string FinalMessage = "Ok, Thanks guys... See you tomorrow.. GoodBye....";

    }
}

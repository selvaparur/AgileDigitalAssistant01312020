﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADAQuestionBank
{
   public class CommonMessages
    {
        public static readonly string StoryGoodShape = "Cool… thanks for progressing & appreciate you for the great work;";
        public static readonly string MoveNextStory = " Ok, Let’s move on to the next story..";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADAQuestionBank
{
    public class ImpedimentsQuestion
    {
        public static readonly string BlockerDetails = "What type of blocker it is, can you please explain in details…..";
        public static readonly string BotAttention = "Ok, thanks for the details.. Do let me know if you require anythng from my end";
    }
}

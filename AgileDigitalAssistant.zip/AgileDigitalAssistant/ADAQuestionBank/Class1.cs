﻿using System;

namespace ADAQuestionBank
{
    public class Class1
    {
    }
}

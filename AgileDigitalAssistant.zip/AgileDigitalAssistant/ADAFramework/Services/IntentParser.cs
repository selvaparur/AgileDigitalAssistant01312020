﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Web;

namespace ADAFramework
{
    public class IntentParser
    {
        public static string GetIntents(string strQuery)
        {
            var strReturn = string.Empty;
            try
            {

                var client = new HttpClient();
                var queryString = HttpUtility.ParseQueryString(string.Empty);

                // This app ID is for a public sample app that recognizes requests to turn on and turn off lights

                //var luisAppId = jObject["luis"]["appid"];// "4e30edff-7662-42b1-a404-086f1a3f9f24";
                //var endpointKey = jObject["luis"]["endpointkey"].ToString(); //"870b6a1afe1f476d88b6786c612ed3de";
                var luisAppId = "a1d0fca9-0c23-4fcd-b485-9625978df3a5";
                var endpointKey = "870b6a1afe1f476d88b6786c612ed3de";

                // The request header contains your subscription key
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", endpointKey);

                // The "q" parameter contains the utterance to send to LUIS
                queryString["q"] = strQuery;

                // These optional request parameters are set to their default values
                queryString["timezoneOffset"] = "0";
                queryString["verbose"] = "false";
                queryString["spellCheck"] = "false";
                queryString["staging"] = "false";

                //var endpointUri = jObject["luis"]["endpoint"].ToString() + luisAppId + "?" + queryString;
                var endpointUri = "https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/" + luisAppId + "?" + queryString;

                //var response = await client.GetAsync(endpointUri);
                var response = client.GetAsync(endpointUri);


                var strResponseContent = response.Result.Content.ReadAsStringAsync();

                // Display the JSON result from LUIS
                strReturn = strResponseContent.Result.ToString();

            }
            catch (Exception ex)
            {

            }
            return strReturn;
        }
    }
}

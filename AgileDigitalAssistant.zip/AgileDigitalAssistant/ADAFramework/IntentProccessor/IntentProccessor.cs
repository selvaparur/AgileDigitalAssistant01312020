﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

using ADADomain;

namespace ADAFramework
{
    public class IntentProccessor
    {
        public static Intents IntentDetails(string strjson)
        {

            return JsonConvert.DeserializeObject<Intents>(strjson);

        }
    }
}

﻿using System;

namespace ADAFramework
{
    public class Class1
    {
    }
}

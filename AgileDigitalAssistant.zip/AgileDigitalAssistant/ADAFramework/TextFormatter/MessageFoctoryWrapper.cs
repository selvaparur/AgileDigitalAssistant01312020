﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;

namespace ADAFramework
{
    public class MessageFoctoryWrapper
    {
        public static Activity GetFormattedMessage(string strMsg)
        {
            return MessageFactory.Text(strMsg, strMsg, InputHints.ExpectingInput);
        }
    }
}

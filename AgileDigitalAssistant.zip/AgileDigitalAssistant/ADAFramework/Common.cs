﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADAFramework
{
    public class Common
    {
        public static string GetFirstLetterUpper(string strName)
        {
            string strReturn = "";

            if (strName.Length == 1)
            {
                strReturn = char.ToUpper(strName[0]).ToString();
            }
            else
            {
                strReturn = char.ToUpper(strName[0]).ToString() + strName.Substring(1);
            }

            return strReturn;
        }
    }
}

﻿using System;

namespace TechnicalIssuesHandler
{
    public class Class1
    {
    }
}

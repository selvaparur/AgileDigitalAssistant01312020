﻿using System;

namespace DependencyHandler
{
    public class Class1
    {
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Microsoft.Bot.Builder.Dialogs;
using System.Threading;
using System.Text;

using ADAFramework;
using ADADomain;
using ImpedimentsHandler;
using ADAQuestionBank;
using CommonHandler;
using DependencyHandler;

namespace AgileDigitalAssistant.Dialogs
{
    public class UserStories : CancelAndHelpDialog
    {
        private string AssignedTo = "";
        UserStoriesSource userStoriesSource1 = null;

        public UserStories(Impediments impediments, AcknowledgmentComponent acknowledgmentComponent, DependencyComponent dependencyComponent,
            UsetStoriesTasks usetStoriesTasks, USInProgress uSInProgress, USNeedsDefinition uSNeedsDefinition, USCompleted uSCompleted, USBlockers uSBlockers) : base(nameof(UserStories))
        {
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(impediments);
            AddDialog(acknowledgmentComponent);
            AddDialog(dependencyComponent);
            AddDialog(usetStoriesTasks);
            AddDialog(uSInProgress);
            AddDialog(uSNeedsDefinition);
            AddDialog(uSCompleted);
            AddDialog(uSBlockers);

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]
            {
                UserStoriesCollectionAsync,
                HandleImpedimentsAsync,
                //TasksglanceAsync,
                FinalStoryAsync

            }));

            InitialDialogId = nameof(WaterfallDialog);
        }

        public async Task<DialogTurnResult> UserStoriesCollectionAsync(WaterfallStepContext context, CancellationToken cancelationToken)
        {
            if (context.Options != null)
            {

                List<UserStoriesSource> userStoriesSources = (List<UserStoriesSource>)context.Options;

                UserStoriesSource userStoriesSource = userStoriesSources.Where(x => x.IsCompleted == false).FirstOrDefault();

                if (userStoriesSource != null)
                {
                    /*
                     userStoriesSource1 = userStoriesSource;

                    StringBuilder stringBuilder = new StringBuilder();

                    //stringBuilder.Append("Let's discuss about User Story " + userStoriesSource.Number + " - " + userStoriesSource.Description);
                    stringBuilder.Append("Let's discuss about UserStory " + userStoriesSource.Number);
                    stringBuilder.Append(". The story is assigned to " + userStoriesSource.AssignedTo + ";" + "How is it going, do you have any blocker on this ?");

                    this.AssignedTo = userStoriesSource.AssignedTo;

                    var stories = MessageFoctoryWrapper.GetFormattedMessage(stringBuilder.ToString());

                    userStoriesSources.Remove(userStoriesSource);
                    userStoriesSources.Append<UserStoriesSource>(userStoriesSource1);

                    return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = stories }, cancelationToken);
                    */

                    userStoriesSource1 = userStoriesSource;

                    StringBuilder stringBuilder = new StringBuilder();

                    //stringBuilder.Append("Let's discuss about User Story " + userStoriesSource.Number + " - " + userStoriesSource.Description);
                    stringBuilder.Append("Let's discuss about UserStory " + userStoriesSource.Number);
                    stringBuilder.Append(". The story is assigned to " + userStoriesSource.AssignedTo + ";" + "How is it going, do you have any blocker on this ?");

                    this.AssignedTo = userStoriesSource.AssignedTo;

                    //var stories = MessageFoctoryWrapper.GetFormattedMessage(stringBuilder.ToString());

                    userStoriesSources.Remove(userStoriesSource);
                    userStoriesSources.Append<UserStoriesSource>(userStoriesSource1);

                    Dictionary<string, string> keyValuePairs = new Dictionary<string, string>();
                    keyValuePairs.Add("AssignedTo", userStoriesSource.AssignedTo);
                    keyValuePairs.Add("StoryNumber", userStoriesSource.Number);


                    USArguments uSArguments = new USArguments()
                    {
                        AssignedTo = userStoriesSource.AssignedTo,
                        Number = userStoriesSource.Number
                    };

                    context.Values["StoryDetails"] = uSArguments;

                    //return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = stories }, cancelationToken);
                    if (userStoriesSource.Status == "InProgress")
                    {
                        return await context.BeginDialogAsync(nameof(USInProgress), uSArguments, cancelationToken);
                    }
                    else if (userStoriesSource.Status == "NeedsDefinition")
                    {
                        return await context.BeginDialogAsync(nameof(USNeedsDefinition), uSArguments, cancelationToken);
                    }
                    else if (userStoriesSource.Status == "Completed")
                    {
                        return await context.BeginDialogAsync(nameof(USCompleted), uSArguments, cancelationToken);
                    }
                    else if (userStoriesSource.Status == "Blocked")
                    {
                        return await context.BeginDialogAsync(nameof(USBlockers), uSArguments, cancelationToken);
                    }
                    return await context.EndDialogAsync(null, cancelationToken);
                }
                else
                    return await context.EndDialogAsync(null, cancelationToken);
            }
            else
                return await context.EndDialogAsync(null, cancelationToken);
        }

        public async Task<DialogTurnResult> HandleImpedimentsAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            bool boolfine = false;
            if (context.Result != null)
            {
                string strImp = (string)context.Result;
                string strName = IntentParser.GetIntents(strImp);
                Intents intents = IntentProccessor.IntentDetails(strName);

                if (!string.IsNullOrEmpty(intents.topScoringIntent.intent))
                {
                    string strIntnet = intents.topScoringIntent.intent;
                    switch (strIntnet)
                    {
                        case "ImpedimentsIntent":
                            return await context.BeginDialogAsync(nameof(Impediments), null, cancellationToken);
                            break;

                        case "BusinessIssuesIntent":
                            break;

                        case "DependencyIntent":
                            return await context.BeginDialogAsync(nameof(DependencyComponent), null, cancellationToken);
                            break;

                        case "TechnicalIssuesIntent":
                            break;

                        case "AcknowledgeIntent":
                            return await context.BeginDialogAsync(nameof(AcknowledgmentComponent), null, cancellationToken);
                            break;

                        default:
                            break;

                    }
                }

            }
            return await context.ReplaceDialogAsync(nameof(UserStories), context.Options, cancellationToken);
            //return await context.EndDialogAsync(null,cancellationToken);

        }


        public async Task<DialogTurnResult> TasksglanceAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {

            context.Values["Tasks"] = userStoriesSource1.Tasks[0].ID;

            return await context.ReplaceDialogAsync(nameof(UsetStoriesTasks), context.Values, cancellationToken);
            //return await context.EndDialogAsync(null,cancellationToken);
        }

        public async Task<DialogTurnResult> FinalStoryAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            return await context.ReplaceDialogAsync(nameof(UserStories), context.Options, cancellationToken);
            //return await context.EndDialogAsync(null,cancellationToken);
        }
    }

    public class USInProgress : CancelAndHelpDialog
    {
        public USInProgress() : base(nameof(USInProgress))
        {
            AddDialog(new TextPrompt(nameof(TextPrompt)));

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[] {

                StartDialogAsync,
                HandleImpedimentsAsync,
                FinalStoryAsync
            }));

            InitialDialogId = nameof(WaterfallDialog);
        }

        public async Task<DialogTurnResult> StartDialogAsync(WaterfallStepContext context, CancellationToken token)
        {
            USArguments uSArguments = context.Options as USArguments;

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("Hey " + uSArguments.AssignedTo + ", UserStory " + uSArguments.Number + " is assigned to you & it is in in-progress, can you please talk about it.. How you are progressing..");

            var stories = MessageFoctoryWrapper.GetFormattedMessage(stringBuilder.ToString());

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = stories }, token);
        }

        public async Task<DialogTurnResult> HandleImpedimentsAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            bool boolfine = false;
            if (context.Result != null)
            {
                string strImp = (string)context.Result;
                string strName = IntentParser.GetIntents(strImp);
                Intents intents = IntentProccessor.IntentDetails(strName);

                if (!string.IsNullOrEmpty(intents.topScoringIntent.intent))
                {
                    string strIntnet = intents.topScoringIntent.intent;
                    switch (strIntnet)
                    {
                        case "ImpedimentsIntent":
                            return await context.BeginDialogAsync(nameof(Impediments), null, cancellationToken);
                            break;

                        case "BusinessIssuesIntent":
                            break;

                        case "DependencyIntent":
                            return await context.BeginDialogAsync(nameof(DependencyComponent), null, cancellationToken);
                            break;

                        case "TechnicalIssuesIntent":
                            break;

                        case "AcknowledgeIntent":
                            return await context.BeginDialogAsync(nameof(AcknowledgmentComponent), null, cancellationToken);
                            break;

                        default:
                            break;

                    }
                }

            }
            return await context.ReplaceDialogAsync(nameof(UserStories), context.Options, cancellationToken);
            //return await context.EndDialogAsync(null,cancellationToken);

        }

        public async Task<DialogTurnResult> FinalStoryAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            return await context.EndDialogAsync(null, cancellationToken);
        }

    }

    public class USNeedsDefinition : CancelAndHelpDialog
    {
        public USNeedsDefinition() : base(nameof(USNeedsDefinition))
        {
            AddDialog(new TextPrompt(nameof(TextPrompt)));

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[] {

                StartDialogAsync,
                HandleImpedimentsAsync,
                AckMessageDialogAsync,
                FinalStoryAsync
            }));

            InitialDialogId = nameof(WaterfallDialog);
        }

        public async Task<DialogTurnResult> StartDialogAsync(WaterfallStepContext context, CancellationToken token)
        {

            USArguments uSArguments = context.Options as USArguments;

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("Ok, "+uSArguments.AssignedTo + ", Story " + uSArguments.Number + " in Needs Definition state. Since the sprint had started yesterday we should not have any stories in Needs Definition. Could you please explain..");

            var stories = MessageFoctoryWrapper.GetFormattedMessage(stringBuilder.ToString());

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = stories }, token);
        }

        public async Task<DialogTurnResult> HandleImpedimentsAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            //bool boolfine = false;
            //if (context.Result != null)
            //{
            //    string strImp = (string)context.Result;
            //    string strName = IntentParser.GetIntents(strImp);
            //    Intents intents = IntentProccessor.IntentDetails(strName);

            //    if (!string.IsNullOrEmpty(intents.topScoringIntent.intent))
            //    {
            //        string strIntnet = intents.topScoringIntent.intent;
            //        switch (strIntnet)
            //        {
            //            case "ImpedimentsIntent":
            //                return await context.BeginDialogAsync(nameof(Impediments), null, cancellationToken);
            //                break;

            //            case "BusinessIssuesIntent":
            //                break;

            //            case "DependencyIntent":
            //                return await context.BeginDialogAsync(nameof(DependencyComponent), null, cancellationToken);
            //                break;

            //            case "TechnicalIssuesIntent":
            //                break;

            //            case "AcknowledgeIntent":
            //                return await context.BeginDialogAsync(nameof(AcknowledgmentComponent), null, cancellationToken);
            //                break;

            //            default:
            //                break;

            //        }
            //    }

            //}
            //return await context.ReplaceDialogAsync(nameof(UserStories), context.Options, cancellationToken);
            ////return await context.EndDialogAsync(null,cancellationToken);

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("Please replace with another defined story from the backlog if you are not able to mitigate today...");

            var stories = MessageFoctoryWrapper.GetFormattedMessage(stringBuilder.ToString());

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = stories }, cancellationToken);

        }

        public async Task<DialogTurnResult> AckMessageDialogAsync(WaterfallStepContext context, CancellationToken token)
        {

            StringBuilder stringBuilder = new StringBuilder();
            //stringBuilder.Append(objInProg["AssignedTo"] + ", Story " + objInProg["StoryNumber"] );
            stringBuilder.Append("ok..");

            var stories = MessageFoctoryWrapper.GetFormattedMessage(stringBuilder.ToString());

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = stories }, token);
        }

        public async Task<DialogTurnResult> FinalStoryAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            return await context.EndDialogAsync(null, cancellationToken);
        }
    }

    public class USCompleted : CancelAndHelpDialog
    {
        public USCompleted() : base(nameof(USCompleted))
        {
            AddDialog(new TextPrompt(nameof(TextPrompt)));

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[] {

                StartDialogAsync,
                HandleImpedimentsAsync,
                FinalStoryAsync
            }));

            InitialDialogId = nameof(WaterfallDialog);
        }
        public async Task<DialogTurnResult> StartDialogAsync(WaterfallStepContext context, CancellationToken token)
        {
            //US54543 - Story in testing state for last 4 days
            //US54546 - Re-opened issue in user story
            //US54547 - Completed but not yet accepted for last 2 days

            USArguments uSArguments = context.Options as USArguments;

            StringBuilder stringBuilder = new StringBuilder();

            if (uSArguments.Number == "US54543")
            {
                stringBuilder.Append(uSArguments.AssignedTo + ", story " + uSArguments.Number + " is in testing state for last 4 days. Is there any blockers you are sturggling with ?");
            }
            else if (uSArguments.Number == "US54546")
            {
                stringBuilder.Append(uSArguments.AssignedTo + ", I can see the defect of userstory " + uSArguments.Number + " is reopened again. Do you want to provide any updates to the team");
            }
            else if (uSArguments.Number == "US54547")
            {
                stringBuilder.Append(uSArguments.AssignedTo + ", Userstory " + uSArguments.Number + " is in completed state and not yet accepted for last 2 days. Were you able to get Product Owner's availability for demo ?");
            }

            var stories = MessageFoctoryWrapper.GetFormattedMessage(stringBuilder.ToString());

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = stories }, token);
        }

        public async Task<DialogTurnResult> HandleImpedimentsAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            USArguments uSArguments = context.Options as USArguments;

            StringBuilder stringBuilder = new StringBuilder();

            if (uSArguments.Number == "US54543")
            {
                stringBuilder.Append("ok, thanks for the update. Do let me know if you need any help from my side");
            }
            else if (uSArguments.Number == "US54546")
            {
                stringBuilder.Append("sure. thanks...");
            }
            else if (uSArguments.Number == "US54547")
            {
                stringBuilder.Append("Let me know if we need to meet with Product Owner for review...");
            }

            var stories = MessageFoctoryWrapper.GetFormattedMessage(stringBuilder.ToString());

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = stories }, cancellationToken);
        }

        public async Task<DialogTurnResult> FinalStoryAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            return await context.EndDialogAsync(null, cancellationToken);
        }
    }

    public class USBlockers : CancelAndHelpDialog
    {
        public USBlockers(SendMailComponent sendMailComponent) : base(nameof(USBlockers))
        {
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(sendMailComponent);

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[] {

                StartDialogAsync,
                HandleImpedimentsAsync,
                FinalStoryAsync
            }));

            InitialDialogId = nameof(WaterfallDialog);
        }
        public async Task<DialogTurnResult> StartDialogAsync(WaterfallStepContext context, CancellationToken token)
        {

            USArguments uSArguments = context.Options as USArguments;

            StringBuilder stringBuilder = new StringBuilder();
            //stringBuilder.Append(objInProg["AssignedTo"] + ", Story " + objInProg["StoryNumber"] );
            stringBuilder.Append("Hey " + uSArguments.AssignedTo + ", " + " I see the story" + uSArguments.Number + " is blocked. Can you explain the blocker ?.");

            var stories = MessageFoctoryWrapper.GetFormattedMessage(stringBuilder.ToString());

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = stories }, token);
        }

        public async Task<DialogTurnResult> HandleImpedimentsAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            // Hey bot can you hold on for a moment, we are discussing something : Ok sure will wait.
            // Hey bot we have completed our discussion please proceed...


            //bool boolfine = false;
            //if (context.Result != null)
            //{
            //    string strImp = (string)context.Result;
            //    string strName = IntentParser.GetIntents(strImp);
            //    Intents intents = IntentProccessor.IntentDetails(strName);

            //    if (!string.IsNullOrEmpty(intents.topScoringIntent.intent))
            //    {
            //        string strIntnet = intents.topScoringIntent.intent;
            //        switch (strIntnet)
            //        {
            //            case "ImpedimentsIntent":
            //                return await context.BeginDialogAsync(nameof(Impediments), null, cancellationToken);
            //                break;

            //            case "BusinessIssuesIntent":
            //                break;

            //            case "DependencyIntent":
            //                return await context.BeginDialogAsync(nameof(DependencyComponent), null, cancellationToken);
            //                break;

            //            case "TechnicalIssuesIntent":
            //                break;

            //            case "AcknowledgeIntent":
            //                return await context.BeginDialogAsync(nameof(AcknowledgmentComponent), null, cancellationToken);
            //                break;

            //            default:
            //                break;

            //        }
            //    }

            //}
            //return await context.ReplaceDialogAsync(nameof(UserStories), context.Options, cancellationToken);
            ////return await context.EndDialogAsync(null,cancellationToken);

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("Do let me know if you need anything from my end to proceed on this? Do you want me to send an e-mail");

            var stories = MessageFoctoryWrapper.GetFormattedMessage(stringBuilder.ToString());

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = stories }, cancellationToken);

        }

        public async Task<DialogTurnResult> FinalStoryAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            if(context.Result.ToString().ToLower().Contains("yes"))
            {
                return await context.BeginDialogAsync(nameof(SendMailComponent), null, cancellationToken);
            }
            else
            return await context.EndDialogAsync(null, cancellationToken);
        }
    }

    public class SendMailComponent : CancelAndHelpDialog
    {
        public SendMailComponent() : base(nameof(SendMailComponent))
        {
            AddDialog(new TextPrompt(nameof(TextPrompt)));

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[] {

                ToDialogAsync,
                SubjectDialogAsync,
                MailSentDialogAsync,
                FinalStoryAsync

            }));

            InitialDialogId = nameof(WaterfallDialog);
        }

        public async Task<DialogTurnResult> ToDialogAsync(WaterfallStepContext context, CancellationToken token)
        {

            USArguments uSArguments = context.Options as USArguments;

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("I am sending email to Selva as I see he is the owner of the dependency story.");

            var stories = MessageFoctoryWrapper.GetFormattedMessage(stringBuilder.ToString());

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = stories }, token);
        }

        public async Task<DialogTurnResult> SubjectDialogAsync(WaterfallStepContext context, CancellationToken token)
        {

            USArguments uSArguments = context.Options as USArguments;

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("Subject is: Userstory US54548 is blocked and required your attention. Is this ok, shall I proceed with the e-mail sending...");

            var stories = MessageFoctoryWrapper.GetFormattedMessage(stringBuilder.ToString());

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = stories }, token);
        }

        public async Task<DialogTurnResult> MailSentDialogAsync(WaterfallStepContext context, CancellationToken token)
        {

            USArguments uSArguments = context.Options as USArguments;

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("The e-mail is sent to Selva.......");

            var stories = MessageFoctoryWrapper.GetFormattedMessage(stringBuilder.ToString());

            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = stories }, token);
        }

        public async Task<DialogTurnResult> FinalStoryAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            return await context.EndDialogAsync(null, cancellationToken);
        }

    }

    public class USArguments
    {
        public string AssignedTo { get; set; }
        public string Number { get; set; }
    }
}

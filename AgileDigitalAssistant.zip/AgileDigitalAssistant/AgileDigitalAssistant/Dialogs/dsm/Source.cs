﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace AgileDigitalAssistant
{
    public class Source
    {

        //public void GetVerbs<T>(string strInupt, ref List<T> t)
        //{
        //    using (var client = new HttpClient())
        //    {
        //        string strURI = string.Empty;

        //        //JObject jObject = JsonParsor.GetConfigurationJson();
        //        //strURI = jObject["JIRA"]["endpoint"].ToString();
        //        //strURI = @"https://phitwiki.cognizant.com/AgileChatBot/Jira/storyDetails";

        //        strURI = @"https://phitwiki.cognizant.com/AgileChatBot/Jira/sprintSummary?ProjectName=AA&sprintName=sprint1 ";

        //        client.BaseAddress = new Uri(strURI);

        //        client.DefaultRequestHeaders.Clear();
        //        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));



        //        var response = client.GetAsync(strInupt).Result;

        //        if (response.IsSuccessStatusCode)
        //        {
        //            var r = response.Content.ReadAsStringAsync().Result;
        //            t = JsonConvert.DeserializeObject<List<T>>(r);
        //        }

        //    }
        //}

        public List<UserStoriesSource> UserStoriesSources()
        {
            /*List<UserStoriesSource> userStories = new List<UserStoriesSource> {
            new UserStoriesSource { Number="US10001",Description="User Story 1",AssignedTo="Sara",Status="Defined",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="1",Descrition="Add User", Status=true} },IsCompleted=false},
            new UserStoriesSource { Number="US54543",Description="User Story 2",AssignedTo="Selva",Status="Completed",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="10",Descrition="Edit User", Status=true} },IsCompleted=true},
            new UserStoriesSource { Number="US54543",Description="User Story 3",AssignedTo="Raja",Status="InProgress",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="5",Descrition="Delete User", Status=false} },IsCompleted=false},
            new UserStoriesSource { Number="US54543",Description="User Story 4",AssignedTo="Arumugam",Status="Completed",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="7",Descrition="Add Patient", Status=true} },IsCompleted=true},
            new UserStoriesSource { Number="US54543",Description="User Story 5",AssignedTo="Micheal",Status="InProgress",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="3",Descrition="Edit Patient", Status= false } },IsCompleted=false},
            new UserStoriesSource { Number="US54543",Description="User Story 6",AssignedTo="Jhon",Status="InProgress",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="2",Descrition="Add User", Status= false } },IsCompleted=false},
            new UserStoriesSource { Number="US54543",Description="User Story 7",AssignedTo="Jackson",Status="InProgress",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="6",Descrition="Add User", Status=true} },IsCompleted=false},
            new UserStoriesSource { Number="US54543",Description="User Story 8",AssignedTo="Ram",Status="InProgress",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="4",Descrition="Add User", Status= false } },IsCompleted=false},
            new UserStoriesSource { Number="US54543",Description="User Story 9",AssignedTo="Kumar",Status="InProgress",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="8",Descrition="Add User", Status=true} },IsCompleted=false},
            new UserStoriesSource { Number="US54543",Description="User Story 10",AssignedTo="Swati",Status="InProgress",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="11",Descrition="Add User", Status= false } },IsCompleted=false}
            };*/

            List<UserStoriesSource> userStories = new List<UserStoriesSource> {
            new UserStoriesSource { Number="US10001",Description="User Story 1",AssignedTo="Jacob",Status="InProgress",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="1",Descrition="Add User", Status=true} },IsCompleted=false},            
            new UserStoriesSource { Number="US54543",Description="User Story 3",AssignedTo="Thomas",Status="NeedsDefinition",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="5",Descrition="Delete User", Status=false} },IsCompleted=false},            
            new UserStoriesSource { Number="US54543",Description="User Story 5",AssignedTo="George",Status="Completed",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="3",Descrition="Edit Patient", Status= false } },IsCompleted=false},
            new UserStoriesSource { Number="US54546",Description="User Story 6",AssignedTo="Wilson",Status="Completed",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="2",Descrition="Add User", Status= false } },IsCompleted=false},
            new UserStoriesSource { Number="US54547",Description="User Story 8",AssignedTo="Micheal",Status="Completed",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="6",Descrition="View User", Status=true} },IsCompleted=false},
            new UserStoriesSource { Number="US54548",Description="User Story 9",AssignedTo="Jackson",Status="Blocked",Tasks=new List<UserStoryTask>{ new UserStoryTask { ID="6",Descrition="Remove User", Status=true} },IsCompleted=false}
            };

            return userStories;
        }
    }

    


    public class UserStoriesSource
    {
        public string Number { get; set; }
        public string Description { get; set; }
        public string AssignedTo { get; set; }

        public List<UserStoryTask>  Tasks { get; set; }
        public string Status { get; set; }
        public bool IsCompleted { get; set; }
    }

    public class UserStoryTask
    {
        public string ID { get; set; }
        public string Descrition { get; set; }

        public bool Status { get; set; }
    }

    public class UserStory
    {
        public string StoryNumber { get; set; }
        public string StoryDescription { get; set; }
        public string StoryOwner { get; set; }
        public string Status { get; set; }
        public string Estimation { get; set; }

        public taskDetails[] TaskDetails { get; set; }
    }

    public class taskDetails
    {
        public string TaskId { get; set; }
        public string TaskDescription { get; set; }
        public string TaskStatus { get; set; }
        public string TaskOwner { get; set; }
    }
}

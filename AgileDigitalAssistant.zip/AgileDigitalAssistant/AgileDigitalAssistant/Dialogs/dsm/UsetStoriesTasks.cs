﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Microsoft.Bot.Builder.Dialogs;
using System.Threading;
using System.Threading.Tasks;
using ADAFramework;
using ADAQuestionBank;
using AgileDigitalAssistant.Dialogs;

namespace AgileDigitalAssistant
{
    public class UsetStoriesTasks : CancelAndHelpDialog
    {

        string strUsers = string.Empty;

        public UsetStoriesTasks() : base(nameof(UsetStoriesTasks))
        {
            AddDialog(new TextPrompt(nameof(TextPrompt)));

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[] {

                StartAsync,
                //AckAsync,
                StopAsync
            }));

            InitialDialogId = nameof(WaterfallDialog);
        }

        public async Task<DialogTurnResult> StartAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            string strUser = string.Empty;

            //if (context.Options != null)
            //{
            //    strUsers = strUser;
            //    strUser = (string)context.Options;

            //}


            //UserStoryTask usetStoriesTasks = new UserStoryTask();
            //Dictionary<string, object> bb;
            //string str = "";
            //if (context.Options != null)
            //{
            //    //usetStoriesTasks = (UserStoryTask)context.Options;
            //    str = (string)context.Options;
            //}

            //var msg = "I see your story has task " + str + " and I hope you are good on that.";
            var msg = "I see your story has 1 task and I hope you are good on that.";

            var pro = MessageFoctoryWrapper.GetFormattedMessage(msg);
            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = pro }, cancellationToken);
        }

        public async Task<DialogTurnResult> AckAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            var pro = MessageFoctoryWrapper.GetFormattedMessage("Ok. Let's move on to the next story...");
            return await context.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = pro }, cancellationToken);
        }

        public async Task<DialogTurnResult> StopAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            return await context.EndDialogAsync(null, cancellationToken);
        }

    }
}

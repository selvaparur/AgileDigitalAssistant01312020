﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Extensions.Logging;
using System.Threading;
using Microsoft.Recognizers.Text.DataTypes.TimexExpression;
using AgileDigitalAssistant.Bots;

using ADAFramework;
using ADAGreetings;
using ADADomain;
using ADAQuestionBank;
using WindupHandler;

namespace AgileDigitalAssistant.Dialogs
{
    public class StandupRunner : CancelAndHelpDialog
    {
        Source source = new Source();
        private UserStoriesSource options;
        protected readonly ILogger Logger;
        GreetingsDomain greetingsDomain = new GreetingsDomain();

        // Dependency injection uses this constructor to instantiate MainDialog
        public StandupRunner(ILogger<MainDialog> logger, UserStories userStories, GreetingMessages greetingMessages, Windup windup)
            : base(nameof(StandupRunner))
        {

            Logger = logger;

            AddDialog(greetingMessages);
            AddDialog(windup);
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(userStories);
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]
            {
                WelcomeWaitAsync,
                WelcomeUsersAsync,
                TimeUpAsync,
                UserStoriesRunAsync,
                WindupAsync,
                ThanksByeAsync,
                FinalStepAsync
            }));
           

            // The initial child Dialog to run.
            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> WelcomeWaitAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var messageText = CustomMessages.IntroMessage;
            var promptMessage = MessageFoctoryWrapper.GetFormattedMessage(messageText);
            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = promptMessage }, cancellationToken);
        }

        private async Task<DialogTurnResult> WelcomeUsersAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {

            return await context.BeginDialogAsync(nameof(GreetingMessages), context.Result, cancellationToken);
        }

        //180000
        private async Task<DialogTurnResult> TimeUpAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            //System.Threading.Thread.Sleep(120000);

            var promptMessage = MessageFactory.Text(CustomMessages.TimeUp, CustomMessages.TimeUp, InputHints.AcceptingInput);
            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = promptMessage }, cancellationToken);
        }

        public async Task<DialogTurnResult> UserStoriesRunAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            Source source = new Source();

            //List<UserStoriesSource> userStoriesSource = new List<UserStoriesSource>();
            UserStoriesSource userStoriesSource = new UserStoriesSource();

            if (stepContext.Values.Count == 0)
            {
                stepContext.Values["UserStories"] = source.UserStoriesSources();
                //source.GetVerbs("", ref userStoriesSource);
                //stepContext.Values["UserStories"] = userStoriesSource;
            }

            if (stepContext.Values["UserStories"] != null)
            {
                List<UserStoriesSource> userStoriesSources = (List<UserStoriesSource>)stepContext.Values["UserStories"];
                userStoriesSource = userStoriesSources.Where(x => x.IsCompleted == false).FirstOrDefault();
                return await stepContext.BeginDialogAsync(nameof(UserStories), userStoriesSources, cancellationToken);
            }

            return await stepContext.NextAsync("ThanksBye", cancellationToken);
            // Use the text provided in FinalStepAsync or the default if it is the first time.
            //var messageText = stepContext.Options?.ToString() ?? "What can I help you with today?\nSay something like \"Book a flight from Paris to Berlin on March 22, 2020\"";
            //var promptMessage = MessageFactory.Text(messageText, messageText, InputHints.ExpectingInput);
            //return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = promptMessage }, cancellationToken);


        }

        public async Task<DialogTurnResult> WindupAsync(WaterfallStepContext context, CancellationToken cancellationToken)
        {
            return await context.BeginDialogAsync(nameof(Windup), null, cancellationToken);
        }

        private async Task<DialogTurnResult> ThanksByeAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // If the child dialog ("BookingDialog") was cancelled, the user failed to confirm or if the intent wasn't BookFlight
            // the Result here will be null.
            /*  if (stepContext.Result is BookingDetails result)
              {
                  // Now we have all the booking details call the booking service.

                  // If the call to the booking service was successful tell the user.

                  var timeProperty = new TimexProperty(result.TravelDate);
                  var travelDateMsg = timeProperty.ToNaturalLanguage(DateTime.Now);
                  var messageText = $"I have you booked to {result.Destination} from {result.Origin} on {travelDateMsg}";
                  var message = MessageFactory.Text(messageText, messageText, InputHints.IgnoringInput);
                  await stepContext.Context.SendActivityAsync(message, cancellationToken);
              }
              */

            // Restart the main dialog with a different message the second time around            
            //var messageText = "Thanks guys… Bye Bye See you tomorrow…";
            var promptMessage = MessageFoctoryWrapper.GetFormattedMessage(WindupQuestions.FinalMessage);// MessageFactory.Text(messageText, messageText, InputHints.ExpectingInput);
            //await stepContext.Context.SendActivityAsync(CreateActivityWithTextAndSpeak(promptMessage));
            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = promptMessage }, cancellationToken);
        }

        private async Task<DialogTurnResult> FinalStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // If the child dialog ("BookingDialog") was cancelled, the user failed to confirm or if the intent wasn't BookFlight
            // the Result here will be null.
            /*  if (stepContext.Result is BookingDetails result)
              {
                  // Now we have all the booking details call the booking service.

                  // If the call to the booking service was successful tell the user.

                  var timeProperty = new TimexProperty(result.TravelDate);
                  var travelDateMsg = timeProperty.ToNaturalLanguage(DateTime.Now);
                  var messageText = $"I have you booked to {result.Destination} from {result.Origin} on {travelDateMsg}";
                  var message = MessageFactory.Text(messageText, messageText, InputHints.IgnoringInput);
                  await stepContext.Context.SendActivityAsync(message, cancellationToken);
              }
              */

            // Restart the main dialog with a different message the second time around                        
            //await stepContext.Context.SendActivityAsync(CreateActivityWithTextAndSpeak(promptMessage));
            return await stepContext.EndDialogAsync(null, cancellationToken);
        }

        public IActivity CreateActivityWithTextAndSpeak(string message)
        {
            var activity = MessageFactory.Text(message);
            string speak = @"<speak version='1.0' xmlns='https://www.w3.org/2001/10/synthesis' xml:lang='en-US'>	
              <voice name='Microsoft Server Speech Text to Speech Voice (en-US, JessaRUS)'>" +
              $"{message}" + "</voice></speak>";
            activity.Speak = speak;
            return activity;
        }
    }
}

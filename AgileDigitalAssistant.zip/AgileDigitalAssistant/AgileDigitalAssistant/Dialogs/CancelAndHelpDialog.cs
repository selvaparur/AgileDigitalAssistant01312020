// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio CoreBot v4.6.2

using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;

namespace AgileDigitalAssistant.Dialogs
{
    public class CancelAndHelpDialog : ComponentDialog
    {
        private const string HelpMsgText = "Show help here";
        private const string CancelMsgText = "Cancelling...";
        bool boolWait;
        public CancelAndHelpDialog(string id)
            : base(id)
        {
        }

        protected override async Task<DialogTurnResult> OnContinueDialogAsync(DialogContext innerDc, CancellationToken cancellationToken = default)
        {
            var result = await InterruptAsync(innerDc, cancellationToken);
            if (result != null)
            {
                return result;
            }

            return await base.OnContinueDialogAsync(innerDc, cancellationToken);
        }

        private async Task<DialogTurnResult> InterruptAsync(DialogContext innerDc, CancellationToken cancellationToken)
        {
            if (innerDc.Context.Activity.Type == ActivityTypes.Message)
            {
                var text = innerDc.Context.Activity.Text.ToLowerInvariant();

                if (boolWait)
                {
                    var helpMessage1 = MessageFactory.Text(text, null, InputHints.ExpectingInput);
                    await innerDc.Context.SendActivityAsync(helpMessage1, cancellationToken);
                    if (text.Contains("completed our discussion") || text.Contains("please proceed"))
                    {
                        boolWait = false;
                        return null;
                    }
                    else
                    {
                        return new DialogTurnResult(DialogTurnStatus.Waiting);
                    }
                }

                // Hey bot we have completed our discussion please proceed...

                if (text.Contains("completed our discussion") || text.Contains("please proceed"))
                {
                    boolWait = false;
                    return null;
                }
                else if (text.Contains("hold on") || text.Contains("can you hold on for a moment")) //Hey bot can you hold on for a moment, we are discussing something
                {
                    boolWait = true;
                    string HelpMsgText1 = "Ok sure will wait...";
                    var helpMessage1 = MessageFactory.Text(HelpMsgText1, HelpMsgText1, InputHints.ExpectingInput);
                    await innerDc.Context.SendActivityAsync(helpMessage1, cancellationToken);
                    return new DialogTurnResult(DialogTurnStatus.Waiting);
                }
                else if ((text == "quit") || (text == "stop"))
                {
                    var cancelMessage = MessageFactory.Text(CancelMsgText, CancelMsgText, InputHints.IgnoringInput);
                    await innerDc.Context.SendActivityAsync(cancelMessage, cancellationToken);
                    return await innerDc.CancelAllDialogsAsync(cancellationToken);
                }

                /*switch (text)
                {
                    case "help":

                    
                    case strr.Contains("hold on"):
                        string HelpMsgText1 = "Waiting...";
                        var helpMessage1 = MessageFactory.Text(HelpMsgText1, HelpMsgText1, InputHints.ExpectingInput);
                        await innerDc.Context.SendActivityAsync(helpMessage1, cancellationToken);
                        return new DialogTurnResult(DialogTurnStatus.Waiting);

                    case "?":
                        var helpMessage = MessageFactory.Text(HelpMsgText, HelpMsgText, InputHints.ExpectingInput);
                        await innerDc.Context.SendActivityAsync(helpMessage, cancellationToken);
                        return new DialogTurnResult(DialogTurnStatus.Waiting);

                    case "cancel":
                    case "quit":
                        var cancelMessage = MessageFactory.Text(CancelMsgText, CancelMsgText, InputHints.IgnoringInput);
                        await innerDc.Context.SendActivityAsync(cancelMessage, cancellationToken);
                        return await innerDc.CancelAllDialogsAsync(cancellationToken);
                }*/
            }

            return null;
        }
    }
}

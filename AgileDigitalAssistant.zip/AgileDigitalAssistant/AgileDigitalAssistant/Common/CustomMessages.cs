﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AgileDigitalAssistant
{
    public class CustomMessages
    {
        public static readonly string IntroMessage = "Good Morning & Good Evening. I'm Stella, your Agile Digital Assistant. Thanks for joining the today’s standup !!!..Let's wait for another couple of minutes.... Is there anyone in the call?";
        public static readonly string TimeUp = "OK, it is more than a minute now. hope everyone has joined...., let's get started...";
    }
}

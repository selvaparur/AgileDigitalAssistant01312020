﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Extensions.Logging;
using System.Threading;

namespace AgileDigitalAssistant.Bots
{
    public class WelcomeDailyStandup<T> : DailyStandupBot<T> where T : Dialog
    {
        public WelcomeDailyStandup(ConversationState conversationState, UserState userState, T dialog, ILogger<DailyStandupBot<T>> logger)
           : base(conversationState, userState, dialog, logger)
        {
        }

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {   

            foreach (var member in membersAdded)
            {
                // Greet anyone that was not the target (recipient) of this message.
                // To learn more about Adaptive Cards, see https://aka.ms/msbot-adaptivecards for more details.
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    //var welcomeCard = CreateAdaptiveCardAttachment();
                    //var response = MessageFactory.Attachment(welcomeCard);
                    var Welresponse = "Welcome to Agile Digital Assistant & thanks for joining today’s standup !!!";
                    //await turnContext.SendActivityAsync(CreateActivityWithTextAndSpeak(Welresponse), cancellationToken);
                    await Dialog.RunAsync(turnContext, ConversationState.CreateProperty<DialogState>("DialogState"), cancellationToken);
                }
            }
        }
        
    }
}
